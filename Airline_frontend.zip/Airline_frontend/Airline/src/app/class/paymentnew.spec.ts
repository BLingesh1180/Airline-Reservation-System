import { Paymentnew } from './paymentnew';

describe('Paymentnew', () => {
  it('should create an instance', () => {
    expect(new Paymentnew()).toBeTruthy();
  });
});
